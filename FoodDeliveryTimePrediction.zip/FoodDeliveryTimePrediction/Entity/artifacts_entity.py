from dataclasses import dataclass

@dataclass
class DataIngestionArtifacts:
    train_file_path:str
    test_file_path:str



@dataclass
class DataValidationArtifacts:
    validation_status:bool
    valid_train_file_path:str
    valid_test_file_path:str
    invalid_train_file_path:str
    invalid_test_file_path:str
    drift_report_file_path:str
    
@dataclass
class DataTransformationArtifacts:
    transformed_object_file_path:str
    transformed_train_file_path:str
    transformed_test_file_path:str
    
@dataclass
class RegressionMetricArtifact:
    r2_score:float
    mean_squared_error:float 
    root_mean_squared_error:float

@dataclass
class ModelTrainerArtifacts:
    trained_model_file_path :str
    train_metric_artifact : RegressionMetricArtifact
    test_metric_artifacts : RegressionMetricArtifact
    model_name : str